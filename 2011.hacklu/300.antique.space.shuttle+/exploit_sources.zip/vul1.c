
unsigned long *ptr;

unsigned long get_sp( void ) {
        __asm__("or %sp,%sp,%i0");
}

void copy( const char *a ){
	char buf[100];
	unsigned long sp;

	puts("copying..");
	printf("sp=%08x\n",sp=get_sp());
	strcpy(buf,a);
	puts("copied OK");

	ptr = get_sp(); printf("[.] will return to %08x\n",*ptr);
}

main( int argc, char *argv[] ) {
        unsigned long sp;

	sp = get_sp();
	printf("sp=%08x\n",sp);

	copy( argv[1] );
	puts("back in main()");
	ptr = get_sp(); printf("[.] will return to %08x\n",*ptr);

//	sp = get_sp();
//	printf("sp=%08x\n",sp);

//	ptr = get_sp(); printf("[.] will return to %08x\n",*ptr);

}

