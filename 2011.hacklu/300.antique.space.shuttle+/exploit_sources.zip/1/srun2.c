/*
 * Generic program for testing shellcode byte arrays.
 * Created by zillion and EVL
 *
 * Safemode.org !! Safemode.org !!
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

/*
 * Print message
 */
static void
croak(const char *msg) {
    fprintf(stderr, "%s\n", msg);
    fflush(stderr);
}
static void
barf(const char *msg) {
    perror(msg);
    exit(1);
}

/*
 * Main code starts here
 */

char code[0x1000];

int
main(int argc, char **argv) {
    FILE        *fp;

    void        (*fptr)(void);

    if(!(fp = fopen(argv[1], "rb"))) barf("failed to open file");
    if(fread(code, 1, sizeof(code), fp) == 0) barf("failed to slurp file");
    if(fclose(fp)) barf("failed to close file");

    croak("Calling code ...");
    fptr = (void (*)(void)) code;
    (*fptr)();
    
    return 0;
}

