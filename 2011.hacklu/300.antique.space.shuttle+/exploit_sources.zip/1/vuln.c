void copy(char *a)
{

     char buffer[512];
     strcpy(buffer, a);

}

main(int argc, char *argv[])
{
	if(argc == 1){
		puts("gimme an arg");
	} else {
	     copy(argv[1]);
	}
}
