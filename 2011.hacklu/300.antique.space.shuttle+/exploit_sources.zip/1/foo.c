
int main(void)
{
        char *a[] = {"/bin/sh", 0};
        execve(a[0], a, 0);
}
