void copy( const char *a ){
	char buf[20];

	strcpy(buf,a);
}

main( int argc, char *argv[] ) {

	printf("[*] vul got %d bytes in argv[1]\n",strlen(argv[1]));
	printf("[*] vul pid %d, copy = %08x\n", getpid(), copy);
	sleep(5);
	copy( argv[1] );

}

