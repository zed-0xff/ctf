/*
 * This little program run a subprogram with the user defined 
 * stack variables.
 *
 * Compilation:
 *  + gcc -o stack_generator stack_generator.c
 *
 * THIS PROGRAM IS FOR EDUCATIONAL PURPOSES *ONLY*
 * IT IS PROVIDED "AS IS" AND WITHOUT ANY WARRANTY
 *
 * (c) 2004 Copyright by Inode <inode@wayreth.eu.org>
 *
 */




#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
//#include <sys/systeminfo.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>


#define VULPROG "./stack"

int main( int argc, char ** argv)
{
	int x, y, pid, number = 0;
	int num_arg = 0, num_env = 0, len_arg = 0, len_env = 0;
	char * env[100];
	char * arg[100];
	char * curr;
	char buff[1000];
	char buf[100];
	char platform[256];
 	unsigned long base = (unsigned long) argv[0]; 	

	fprintf( stderr, "\nSolaris Sparc Stack Generator v0.1\n");

	if( argc != 6 ) {
		fprintf(stdout, "\n%s <prog len> <n args> <arg len> <n env> <env len>\n",argv[0]);
		exit(0);
	}

	number = atoi( argv[2] );

	base = ( base | 0xffff ) & 0xfffffffc;

	srand((unsigned)time(NULL));

//	sysinfo(SI_PLATFORM, platform, sizeof(platform));

	num_arg =  atoi(argv[2]);
	num_env =  atoi(argv[4]);

       	env[ num_env ] = NULL;
	arg[ num_arg ] = NULL;

	for( x = 0; x < num_arg; x++) 
	{
		if( x + 1 != num_arg)
			y = atoi(argv[3]) / atoi(argv[2]);
		else
			y =  atoi(argv[3]) - len_arg ;

		curr = (char *)malloc(y);
		memset( curr, 'A', y-1);
		curr[y-1]= 0;
		len_arg += strlen(curr) + 1;
		arg[ x ] = curr;
	}

	for( x = 0; x < num_env; x++) {
		if( x + 1 != num_env)
                        y = atoi(argv[5]) / atoi(argv[4]);
                else
			y =  atoi(argv[5]) - len_env;

		curr = (char *)malloc(y);
		memset( curr, 'A', y-1);
		curr[y-1]= 0;
		len_env += strlen(curr) + 1;
		env[ x ] = curr;
	}

	memset( buf,0,sizeof(buf));
	memset( buf,'A', atoi(argv[1])-1 );
	sprintf(buff, "cp %s %s",VULPROG,buf);
	system( buff );

	sprintf(buff, "./%s", buf);

	fprintf(stdout,"\nNum args     : %d\n", num_arg);
	fprintf(stdout,"Num envs     : %d\n", num_env);
	fprintf(stdout,"Len args     : %d\n", len_arg);
	fprintf(stdout,"Len envs     : %d\n", len_env);
//	fprintf(stdout,"Platform len : %d\n", strlen( platform ) + 1 );
	fprintf(stdout,"Progname len : %d\n", strlen( (char *)(strrchr(buff,'/') + 1 )) + 1 );
	fprintf(stdout,"Stack base   : 0x%p\n\n", (char*)base);

	if ((pid=fork()) < 0)
	{
		perror ("Fork failed");
		exit(0);
	}

	if (!pid){
		execve(buff, arg, env);
	}
	else
		waitpid (pid, NULL, 0);

	unlink( buff );

	{ FILE*f = fopen("tpl.dat","wb"); fwrite(arg[0],1,len_arg,f); fclose(f); }

	return 0;
}
