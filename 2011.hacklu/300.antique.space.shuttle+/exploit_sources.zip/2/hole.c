int copy(char *str)
{
   char buf[100];
   strcpy(buf,str);
}

int main(int argc, char **argv)
{
   printf("[.] my pid = %d\n",getpid());
//   sleep(5);
   copy(argv[1]);
}

