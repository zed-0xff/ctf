#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int copy(char *str)
{
   char buf[100];
   strcpy(buf,str);
}

int main(int argc, char **argv)
{
   int i;
   printf("[.] got %d args\n",argc);
   for(i=0;i<argc;i++){
	FILE*f;
	char fname[0x20];

	printf("argv[%d] = %d bytes\n",i,strlen(argv[i]));
	sprintf(fname,"argv_%d",i);
	f = fopen(fname,"wb"); fwrite(argv[i],1,strlen(argv[i]),f); fclose(f);
	
   }
//   copy(argv[1]);
}

